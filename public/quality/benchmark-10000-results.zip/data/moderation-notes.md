# Moderation changes for the 10,000-message benchmark

Scope: `lib/message-moderation.ts`, new `lib/multilingual-moderation.ts`, and new `lib/multilingual-moderation.test.ts`. No routing, storage, deployment or evaluation-label changes were made by this agent.

What changed:
- Added a curated word-family lexicon for Ukrainian, Kazakh and Uzbek authored insults (including supported Latin/Cyrillic alternatives). These are general lexemes and grammar rules, not complete evaluation sentences or scenario identifiers.
- Added strict one-edit/one-mask repair for long known insult words, repeated letters, mixed visual letters, and separated fragments. A repair must resolve to one known family. First-person suffixes are protected; second-person suffixes retain their grammatical meaning.
- Added foreign-language attribution, quoted-speech, negation, self-description and incident/affected-person checks. A role word plus profanity is not sufficient when the message reports someone else's behavior. Quotes are only reattributed to the author with explicit authorship/addressing evidence.
- Added authored obscene-dismissal constructions and limited explicit off-game threat patterns.
- Extended Russian moderation for explicit present-tense self-authorship, relative recipients, additional strong personal insult forms, and bounded joined words. Existing mocking-spam logic remains.

Validation:
- 359/359 focused moderation tests pass, including 100 new independently constructed contrast cases. Existing moderation expectations were not edited.
- TypeScript no-emit validation passes.
- Full combined project suite during concurrent edits was 911/918. All moderation tests passed. Seven failures were in normalization/routing owned by other agents; root and normalizer agent were notified with the detailed output in all-tests-moderation.txt. Root should run final suite after all edits settle.
- Raw-text component diagnostic is recorded separately as moderation-component-audit.json. It is NOT a full pipeline benchmark and must not be counted as one of the user's official runs. It retains every missed expected violation and every false positive relative to the proposed answer key.

Limits:
- Proposed synthetic labels are not a human-certified gold standard. A missing lexical family, deeply fused text, opaque transliteration, implicit non-profane intimidation, or ambiguous attribution may remain unresolved. The rules deliberately prefer unresolved/review over charging a reported quotation as the author's abuse.
- No generated private holdout was read or used. No LLM, external API, training model or whole-corpus lookup was added to production.
- Full source and all-data checks must be taken from root's timestamped snapshot for each official run; concurrent local component checks cannot replace them.
